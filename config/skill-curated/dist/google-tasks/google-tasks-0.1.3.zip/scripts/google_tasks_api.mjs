import process from 'node:process'

const BASE_URL = 'https://tasks.googleapis.com/tasks/v1'

function fail(message, details) {
  if (details) {
    process.stderr.write(`${message}\n${details}\n`)
  } else {
    process.stderr.write(`${message}\n`)
  }
  process.exit(1)
}

function requireAccessToken() {
  const token = (process.env.GOOGLE_ACCESS_TOKEN || '').trim()
  if (!token) {
    fail('Error: GOOGLE_ACCESS_TOKEN is not set. Connect a Google account in Sanqian first.')
  }
  return token
}

function parseArgs(argv) {
  const positional = []
  const options = {}
  for (let index = 0; index < argv.length; index += 1) {
    const current = argv[index]
    if (!current.startsWith('--')) {
      positional.push(current)
      continue
    }
    const key = current.slice(2)
    const next = argv[index + 1]
    if (next && !next.startsWith('--')) {
      options[key] = next
      index += 1
      continue
    }
    options[key] = 'true'
  }
  return { positional, options }
}

function requireOption(options, key, message) {
  const value = options[key]
  if (value === undefined || value === '') {
    fail(message || `Missing required option --${key}`)
  }
  return value
}

function resolveTaskListId(options) {
  return options.list || process.env.GOOGLE_TASKS_LIST_ID || ''
}

function normalizeDue(value) {
  if (!value) {
    return undefined
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return `${value}T00:00:00.000Z`
  }
  return value
}

async function request(method, path, { query, body } = {}) {
  const normalizedBaseUrl = BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`
  const normalizedPath = path.startsWith('/') ? path.slice(1) : path
  const url = new URL(normalizedPath, normalizedBaseUrl)
  for (const [key, value] of Object.entries(query || {})) {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, String(value))
    }
  }

  const headers = {
    Authorization: `Bearer ${requireAccessToken()}`,
    Accept: 'application/json',
  }

  const init = { method, headers }
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json'
    init.body = JSON.stringify(body)
  }

  const response = await fetch(url, init)
  if (!response.ok) {
    const text = await response.text()
    fail(`Google Tasks API request failed (${response.status})`, text)
  }
  if (response.status === 204) {
    return null
  }
  return response.json()
}

async function listTaskLists() {
  const payload = await request('GET', '/users/@me/lists')
  console.log(JSON.stringify(payload, null, 2))
}

async function getTaskList(taskListId) {
  const payload = await request('GET', `/users/@me/lists/${encodeURIComponent(taskListId)}`)
  console.log(JSON.stringify(payload, null, 2))
}

async function createTaskList(options) {
  const title = requireOption(options, 'title')
  const payload = await request('POST', '/users/@me/lists', {
    body: { title },
  })
  console.log(JSON.stringify(payload, null, 2))
}

async function updateTaskList(options) {
  const taskListId = resolveTaskListId(options)
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for update-list')
  }
  const title = requireOption(options, 'title')
  const payload = await request('PATCH', `/users/@me/lists/${encodeURIComponent(taskListId)}`, {
    body: { title },
  })
  console.log(JSON.stringify(payload, null, 2))
}

async function deleteTaskList(options) {
  const taskListId = resolveTaskListId(options)
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for delete-list')
  }
  await request('DELETE', `/users/@me/lists/${encodeURIComponent(taskListId)}`)
  console.log(JSON.stringify({ deleted: true, task_list_id: taskListId }, null, 2))
}

async function listTasks(options) {
  const taskListId = resolveTaskListId(options)
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for list')
  }
  const payload = await request('GET', `/lists/${encodeURIComponent(taskListId)}/tasks`, {
    query: {
      maxResults: options.max,
      showCompleted: options['show-completed'],
      showHidden: options['show-hidden'],
      dueMin: normalizeDue(options['due-min']),
      dueMax: normalizeDue(options['due-max']),
    },
  })
  console.log(JSON.stringify(payload, null, 2))
}

async function getTask(options) {
  const taskListId = resolveTaskListId(options)
  const taskId = requireOption(options, 'task')
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for get')
  }
  const payload = await request(
    'GET',
    `/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
  )
  console.log(JSON.stringify(payload, null, 2))
}

function buildTaskBody(options, { requireTitle = false } = {}) {
  const body = {}
  if (options.title) {
    body.title = options.title
  } else if (requireTitle) {
    fail('Missing required option --title')
  }
  if (options.notes !== undefined) {
    body.notes = options.notes
  }
  if (options.due) {
    body.due = normalizeDue(options.due)
  }
  if (options.parent) {
    body.parent = options.parent
  }
  if (options.status) {
    body.status = options.status
  }
  return body
}

async function createTask(options) {
  const taskListId = resolveTaskListId(options)
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for create')
  }
  const payload = await request('POST', `/lists/${encodeURIComponent(taskListId)}/tasks`, {
    body: buildTaskBody(options, { requireTitle: true }),
  })
  console.log(JSON.stringify(payload, null, 2))
}

async function updateTask(options) {
  const taskListId = resolveTaskListId(options)
  const taskId = requireOption(options, 'task')
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for update')
  }
  const payload = await request(
    'PATCH',
    `/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
    {
      body: buildTaskBody(options),
    },
  )
  console.log(JSON.stringify(payload, null, 2))
}

async function completeTask(options, status) {
  const taskListId = resolveTaskListId(options)
  const taskId = requireOption(options, 'task')
  if (!taskListId) {
    fail(`Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for ${status === 'completed' ? 'complete' : 'reopen'}`)
  }
  const payload = await request(
    'PATCH',
    `/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
    {
      body: { status },
    },
  )
  console.log(JSON.stringify(payload, null, 2))
}

async function deleteTask(options) {
  const taskListId = resolveTaskListId(options)
  const taskId = requireOption(options, 'task')
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for delete')
  }
  await request(
    'DELETE',
    `/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
  )
  console.log(JSON.stringify({ deleted: true, task_list_id: taskListId, task_id: taskId }, null, 2))
}

async function clearTasks(options) {
  const taskListId = resolveTaskListId(options)
  if (!taskListId) {
    fail('Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for clear')
  }
  await request('POST', `/lists/${encodeURIComponent(taskListId)}/clear`)
  console.log(JSON.stringify({ cleared: true, task_list_id: taskListId }, null, 2))
}

async function main() {
  const { positional, options } = parseArgs(process.argv.slice(2))
  const command = positional[0]
  if (!command) {
    fail(
      'Usage: node scripts/google_tasks_api.mjs <lists|get-list|create-list|update-list|delete-list|list|get|create|update|complete|reopen|delete|clear> [options]',
    )
  }

  switch (command) {
    case 'lists':
      await listTaskLists()
      break
    case 'get-list':
      await getTaskList(requireOption({ list: resolveTaskListId(options) }, 'list', 'Missing --list <task_list_id> (or GOOGLE_TASKS_LIST_ID) for get-list'))
      break
    case 'create-list':
      await createTaskList(options)
      break
    case 'update-list':
      await updateTaskList(options)
      break
    case 'delete-list':
      await deleteTaskList(options)
      break
    case 'list':
      await listTasks(options)
      break
    case 'get':
      await getTask(options)
      break
    case 'create':
      await createTask(options)
      break
    case 'update':
      await updateTask(options)
      break
    case 'complete':
      await completeTask(options, 'completed')
      break
    case 'reopen':
      await completeTask(options, 'needsAction')
      break
    case 'delete':
      await deleteTask(options)
      break
    case 'clear':
      await clearTasks(options)
      break
    default:
      fail(`Unknown command: ${command}`)
  }
}

main().catch((error) => {
  fail(error instanceof Error ? error.message : 'Unknown error', error?.stack)
})
