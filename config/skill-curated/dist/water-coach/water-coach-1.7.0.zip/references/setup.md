# Water Coach Setup

## Data Location

User data is stored outside the skill package:
- `$SANQIAN_DATA_DIR/skill-data/water-coach/water_config.json`
- `$SANQIAN_DATA_DIR/skill-data/water-coach/water_log.csv`
- `$SANQIAN_DATA_DIR/skill-data/water-coach/body_metrics.csv`

## Setup Checklist

- [ ] Create data files (auto-created on first run)
- [ ] Ask user for weight or explicit hydration goal
- [ ] **CONFIRM goal with user**
- [ ] Capture preferred reminder times if the host app supports scheduled nudges

## 1. Create Data Files

The data folder is created automatically on first run:
```bash
python3 scripts/water_coach.py water status
```

---

## 2. Ask User Weight

If the user does not already have a configured goal, ask for weight or a direct target.

```bash
python3 scripts/water_coach.py water set_body_weight 80
```

## 3. CONFIRM Goal (IMPORTANT!)

> **GOAL is USER'S CHOICE, not automatic!**

After setting weight, agent MUST ask:

```
"Your weight is 80kg. 
Based on this, the suggested goal is 2800ml (80 × 35ml).

Is this goal OK for you? 
Or do you want a different goal? (e.g., doctor recommended 1.5L)"
```

If user wants different goal:
```bash
# Update config manually or ask user their preferred goal
```

## 4. Reminder Integration

The skill itself does not schedule reminders. If the host app supports automations:

- save user reminder times in `water_config.json`
- run `python3 scripts/water_coach.py water status` or `python3 scripts/water_coach.py water dynamic` on that schedule
- only send a message when the host decides it is appropriate

## Verify Setup

```bash
python3 scripts/water_coach.py water status
python3 scripts/water_coach.py water goal
```
