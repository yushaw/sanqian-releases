---
name: asana
description: "Manage Asana tasks, projects, and workspaces through a Sanqian-managed OAuth connection. Use when the user needs to inspect projects, search tasks, update tasks, add comments, or create new tasks in Asana."
---

# Asana

## Overview

This skill uses the Asana REST API through a Sanqian-managed OAuth connection.
Sanqian owns the OAuth client configuration, refresh state, and browser connect
flow. The runtime surface only consumes a short-lived `ASANA_ACCESS_TOKEN`.

The main command surface lives in `scripts/asana_api.mjs`.

## Runtime auth

- `ASANA_ACCESS_TOKEN`
  Short-lived access token injected by Sanqian after the user connects an
  Asana account. Do not ask the user to paste refresh tokens, client IDs, or
  client secrets into this skill.

## Runtime state

- Default state path: `~/.sanqian/skill-data/asana/config.json`
- Optional override: set `ASANA_STATE_DIR` to move the local config directory
- Optional workspace override: set `ASANA_DEFAULT_WORKSPACE_GID` to bypass the
  saved default workspace

The skill only persists non-secret defaults such as the preferred workspace.

## Quick Start

After Sanqian shows the Asana account as connected:

```bash
node scripts/asana_api.mjs me
node scripts/asana_api.mjs workspaces
```

Save a default workspace once:

```bash
node scripts/asana_api.mjs set-default-workspace --workspace <workspace_gid>
```

Then list projects or your assigned tasks:

```bash
node scripts/asana_api.mjs projects
node scripts/asana_api.mjs tasks-assigned --assignee me
```

## Commands

Inspect account and workspace data:

```bash
node scripts/asana_api.mjs me
node scripts/asana_api.mjs workspaces
node scripts/asana_api.mjs projects --workspace <workspace_gid>
```

Inspect or search tasks:

```bash
node scripts/asana_api.mjs tasks-in-project --project <project_gid>
node scripts/asana_api.mjs tasks-assigned --workspace <workspace_gid> --assignee me
node scripts/asana_api.mjs search-tasks --workspace <workspace_gid> --text "release" --assignee me
node scripts/asana_api.mjs task <task_gid>
```

Mutate tasks:

```bash
node scripts/asana_api.mjs update-task <task_gid> --name "New title" --due_on 2026-04-01
node scripts/asana_api.mjs complete-task <task_gid>
node scripts/asana_api.mjs comment <task_gid> --text "Update: shipped"
node scripts/asana_api.mjs create-task --workspace <workspace_gid> --name "Follow up"
```

## Notes

- Required OAuth scopes are governed by the curated manifest, not by ad hoc
  shell setup.
- Asana account connection requires the host-side provider config to use the
  hosted redirect URI `https://auth.sanqian.ai/skills/auth/callback`.
- This package intentionally removes the upstream OOB/manual code-paste setup
  flow. Brokered OAuth is the only supported runtime model in Sanqian.
