---
name: gws-tasks
description: "Create, list, and complete tasks in Google Tasks. Use when the user mentions to-do items, task lists, reminders, or Google Tasks."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/tasks
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Google Tasks

## List task lists

```bash
gws tasks tasklists list
```

Use the task list ID from the result for all task operations below.

## List tasks

```bash
gws tasks tasks list --params '{"tasklist": "<TASKLIST_ID>"}'
gws tasks tasks list --params '{"tasklist": "<TASKLIST_ID>", "showCompleted": false}'
```

## Create task

```bash
gws tasks tasks insert --params '{"tasklist": "<TASKLIST_ID>"}' --json '{"title": "Review PR #42", "notes": "Check test coverage", "due": "2026-01-20T00:00:00Z"}'
```

`due` and `notes` are optional.

## Complete task

```bash
gws tasks tasks patch --params '{"tasklist": "<TASKLIST_ID>", "task": "<TASK_ID>"}' --json '{"status": "completed"}'
```

## Update task

```bash
gws tasks tasks patch --params '{"tasklist": "<TASKLIST_ID>", "task": "<TASK_ID>"}' --json '{"title": "Updated title"}'
```

## Delete task

```bash
gws tasks tasks delete --params '{"tasklist": "<TASKLIST_ID>", "task": "<TASK_ID>"}'
```

## Create task list

```bash
gws tasks tasklists insert --json '{"title": "Work"}'
```

Confirm before deleting tasks or task lists.
