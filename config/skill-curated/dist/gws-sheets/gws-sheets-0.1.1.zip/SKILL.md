---
name: gws-sheets
description: "Read, write, and analyze data in Google Sheets. Use when the user mentions spreadsheets, Google Sheets, tabular data, or wants to read/write rows and cells."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/spreadsheets
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Google Sheets

## Quick helpers

```bash
gws sheets +read --spreadsheet <SPREADSHEET_ID> --range "Sheet1!A1:C10"
gws sheets +append --spreadsheet <SPREADSHEET_ID> --values "Alice,95,A"
```

## Read values

```bash
gws sheets spreadsheets.values get --params '{"spreadsheetId": "<SPREADSHEET_ID>", "range": "Sheet1!A1:D10"}'
```

## Write values

```bash
gws sheets spreadsheets.values update --params '{"spreadsheetId": "<SPREADSHEET_ID>", "range": "Sheet1!A1", "valueInputOption": "USER_ENTERED"}' --json '{"values": [["Name", "Score"], ["Alice", 95]]}'
```

`valueInputOption`: `USER_ENTERED` (parses formulas/dates) or `RAW` (literal strings).

## Append rows

```bash
gws sheets spreadsheets.values append --params '{"spreadsheetId": "<SPREADSHEET_ID>", "range": "Sheet1!A1", "valueInputOption": "USER_ENTERED"}' --json '{"values": [["Bob", 88]]}'
```

Appends after the last row with data in the specified range.

## Create spreadsheet

```bash
gws sheets spreadsheets create --json '{"properties": {"title": "Q1 Budget"}}'
```

## Get spreadsheet metadata

```bash
gws sheets spreadsheets get --params '{"spreadsheetId": "<SPREADSHEET_ID>"}'
```

Returns sheet names, grid properties, and named ranges. Use this to discover sheet names before reading.

## Batch update (formatting, merging, adding sheets)

```bash
gws sheets spreadsheets batchUpdate --params '{"spreadsheetId": "<SPREADSHEET_ID>"}' --json '{"requests": [{"addSheet": {"properties": {"title": "Summary"}}}]}'
```

Common request types: `addSheet`, `deleteSheet`, `mergeCells`, `repeatCell` (formatting), `autoResize`.

Confirm before overwriting existing data. Prefer append over update for adding new rows.
