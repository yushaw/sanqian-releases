---
name: gws-slides
description: "Create and edit Google Slides presentations. Use when the user mentions presentations, slides, decks, or wants to create/modify slide content."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/presentations
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Google Slides

## Create presentation

```bash
gws slides presentations create --json '{"title": "Q1 Review"}'
```

## Get presentation

```bash
gws slides presentations get --params '{"presentationId": "<PRESENTATION_ID>"}'
```

Returns all slides with their page IDs and shape IDs. Read this first to discover IDs for editing.

## Add a blank slide

```bash
gws slides presentations batchUpdate --params '{"presentationId": "<PRESENTATION_ID>"}' --json '{
  "requests": [
    {
      "createSlide": {
        "slideLayoutReference": {"predefinedLayout": "BLANK"}
      }
    }
  ]
}'
```

Layouts: `TITLE`, `TITLE_AND_BODY`, `TITLE_AND_TWO_COLUMNS`, `BLANK`, `SECTION_HEADER`, and more.

## Insert text into a shape

First get the presentation to find shape IDs, then:

```bash
gws slides presentations batchUpdate --params '{"presentationId": "<PRESENTATION_ID>"}' --json '{
  "requests": [
    {
      "insertText": {
        "objectId": "<SHAPE_ID>",
        "text": "Slide content here"
      }
    }
  ]
}'
```

## Replace placeholder text

```bash
gws slides presentations batchUpdate --params '{"presentationId": "<PRESENTATION_ID>"}' --json '{
  "requests": [
    {
      "replaceAllText": {
        "containsText": {"text": "{{TITLE}}", "matchCase": true},
        "replaceText": "Quarterly Business Review"
      }
    }
  ]
}'
```

Multiple requests can be combined in a single batchUpdate call. Confirm before modifying existing presentations.
