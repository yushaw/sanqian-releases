import process from 'node:process'

const BASE_URL = 'https://www.googleapis.com/calendar/v3'

function fail(message, details) {
  if (details) {
    process.stderr.write(`${message}\n${details}\n`)
  } else {
    process.stderr.write(`${message}\n`)
  }
  process.exit(1)
}

function requireAccessToken() {
  const token = (process.env.GOOGLE_ACCESS_TOKEN || '').trim()
  if (!token) {
    fail('Error: GOOGLE_ACCESS_TOKEN is not set. Connect a Google account in Sanqian first.')
  }
  return token
}

function parseArgs(argv) {
  const positional = []
  const options = {}
  for (let index = 0; index < argv.length; index += 1) {
    const current = argv[index]
    if (!current.startsWith('--')) {
      positional.push(current)
      continue
    }
    const key = current.slice(2)
    const next = argv[index + 1]
    if (next && !next.startsWith('--')) {
      options[key] = next
      index += 1
      continue
    }
    options[key] = 'true'
  }
  return { positional, options }
}

function requireOption(options, key, message) {
  const value = options[key]
  if (value === undefined || value === '') {
    fail(message || `Missing required option --${key}`)
  }
  return value
}

function resolveCalendarId(options) {
  return options.calendar || process.env.GOOGLE_CALENDAR_ID || 'primary'
}

function buildEventDateTime(value) {
  if (!value) {
    return undefined
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return { date: value }
  }
  return { dateTime: value }
}

async function request(method, path, { query, body } = {}) {
  const url = new URL(path, BASE_URL)
  for (const [key, value] of Object.entries(query || {})) {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, String(value))
    }
  }

  const headers = {
    Authorization: `Bearer ${requireAccessToken()}`,
    Accept: 'application/json',
  }

  const init = { method, headers }
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json'
    init.body = JSON.stringify(body)
  }

  const response = await fetch(url, init)
  if (!response.ok) {
    const text = await response.text()
    fail(`Google Calendar API request failed (${response.status})`, text)
  }
  if (response.status === 204) {
    return null
  }
  return response.json()
}

async function listCalendars() {
  const payload = await request('GET', '/users/me/calendarList')
  console.log(JSON.stringify(payload, null, 2))
}

async function listEvents(options) {
  const payload = await request(
    'GET',
    `/calendars/${encodeURIComponent(resolveCalendarId(options))}/events`,
    {
      query: {
        timeMin: options.from,
        timeMax: options.to,
        q: options.query,
        maxResults: options.max || 10,
        singleEvents: 'true',
        orderBy: 'startTime',
      },
    },
  )
  console.log(JSON.stringify(payload, null, 2))
}

async function getEvent(options) {
  const eventId = requireOption(options, 'event-id')
  const payload = await request(
    'GET',
    `/calendars/${encodeURIComponent(resolveCalendarId(options))}/events/${encodeURIComponent(eventId)}`,
  )
  console.log(JSON.stringify(payload, null, 2))
}

function buildEventBody(options, { requireTitle = false, requireStart = false, requireEnd = false } = {}) {
  const body = {}
  if (options.title) {
    body.summary = options.title
  } else if (requireTitle) {
    fail('Missing required option --title')
  }
  if (options.start) {
    body.start = buildEventDateTime(options.start)
  } else if (requireStart) {
    fail('Missing required option --start')
  }
  if (options.end) {
    body.end = buildEventDateTime(options.end)
  } else if (requireEnd) {
    fail('Missing required option --end')
  }
  if (options.desc !== undefined) {
    body.description = options.desc
  }
  if (options.location !== undefined) {
    body.location = options.location
  }
  if (options.attendees !== undefined) {
    body.attendees = options.attendees
      ? options.attendees
          .split(',')
          .map((email) => email.trim())
          .filter(Boolean)
          .map((email) => ({ email }))
      : []
  }
  return body
}

async function addEvent(options) {
  const payload = await request(
    'POST',
    `/calendars/${encodeURIComponent(resolveCalendarId(options))}/events`,
    {
      body: buildEventBody(options, {
        requireTitle: true,
        requireStart: true,
        requireEnd: true,
      }),
    },
  )
  console.log(JSON.stringify(payload, null, 2))
}

async function updateEvent(options) {
  const eventId = requireOption(options, 'event-id')
  const payload = await request(
    'PATCH',
    `/calendars/${encodeURIComponent(resolveCalendarId(options))}/events/${encodeURIComponent(eventId)}`,
    {
      body: buildEventBody(options),
    },
  )
  console.log(JSON.stringify(payload, null, 2))
}

async function deleteEvent(options) {
  const eventId = requireOption(options, 'event-id')
  await request(
    'DELETE',
    `/calendars/${encodeURIComponent(resolveCalendarId(options))}/events/${encodeURIComponent(eventId)}`,
  )
  console.log(JSON.stringify({ deleted: true, calendar_id: resolveCalendarId(options), event_id: eventId }, null, 2))
}

async function main() {
  const { positional, options } = parseArgs(process.argv.slice(2))
  const command = positional[0]
  if (!command) {
    fail(
      'Usage: node scripts/google_calendar_api.mjs <calendars|list|get|add|update|delete> [options]',
    )
  }

  switch (command) {
    case 'calendars':
      await listCalendars()
      break
    case 'list':
      await listEvents(options)
      break
    case 'get':
      await getEvent(options)
      break
    case 'add':
      await addEvent(options)
      break
    case 'update':
      await updateEvent(options)
      break
    case 'delete':
      await deleteEvent(options)
      break
    default:
      fail(`Unknown command: ${command}`)
  }
}

main().catch((error) => {
  fail(error instanceof Error ? error.message : 'Unknown error', error?.stack)
})
