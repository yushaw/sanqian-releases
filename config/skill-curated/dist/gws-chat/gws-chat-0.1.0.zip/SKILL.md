---
name: gws-chat
description: "Send and read messages in Google Chat spaces. Use when the user mentions Google Chat, team messaging, or wants to communicate with colleagues."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: external
      check_command: "gws auth status"
      check_success_pattern: "token_valid.*true"
---

# Google Chat

## List spaces

List spaces first to get the space ID:

```bash
gws chat spaces list
```

## Send message

```bash
gws chat +send --space spaces/<SPACE_ID> --text "Deploy complete."
```

Or via the API method:

```bash
gws chat spaces.messages create --params '{"parent": "spaces/<SPACE_ID>"}' --json '{"text": "Hello team!"}'
```

## Reply in a thread

```bash
gws chat spaces.messages create --params '{"parent": "spaces/<SPACE_ID>"}' --json '{"text": "Noted.", "thread": {"name": "spaces/<SPACE_ID>/threads/<THREAD_ID>"}}'
```

Get `thread.name` from an existing message in the list result.

## List messages in a space

```bash
gws chat spaces.messages list --params '{"parent": "spaces/<SPACE_ID>", "pageSize": 10}'
```

## List members

```bash
gws chat spaces.members list --params '{"parent": "spaces/<SPACE_ID>"}'
```

Confirm before sending messages to shared spaces.
