---
name: gws-sheets
description: "Read, write, and analyze data in Google Sheets. Use when the user mentions spreadsheets, Google Sheets, tabular data, or wants to read/write rows and cells."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: external
      check_command: "gws auth status"
      check_success_pattern: "token_valid.*true"
---

# Google Sheets

## Quick helpers

```bash
gws sheets +read --spreadsheet <SPREADSHEET_ID> --range "Sheet1!A1:C10"
gws sheets +append --spreadsheet <SPREADSHEET_ID> --values "Alice,95,A"
```

## Read values

```bash
gws sheets spreadsheets.values get --params '{"spreadsheetId": "<SPREADSHEET_ID>", "range": "Sheet1!A1:D10"}'
```

## Write values

```bash
gws sheets spreadsheets.values update --params '{"spreadsheetId": "<SPREADSHEET_ID>", "range": "Sheet1!A1", "valueInputOption": "USER_ENTERED"}' --json '{"values": [["Name", "Score"], ["Alice", 95]]}'
```

`valueInputOption`: `USER_ENTERED` (parses formulas/dates) or `RAW` (literal strings).

## Append rows

```bash
gws sheets spreadsheets.values append --params '{"spreadsheetId": "<SPREADSHEET_ID>", "range": "Sheet1!A1", "valueInputOption": "USER_ENTERED"}' --json '{"values": [["Bob", 88]]}'
```

Appends after the last row with data in the specified range.

## Create spreadsheet

```bash
gws sheets spreadsheets create --json '{"properties": {"title": "Q1 Budget"}}'
```

## Get spreadsheet metadata

```bash
gws sheets spreadsheets get --params '{"spreadsheetId": "<SPREADSHEET_ID>"}'
```

Returns sheet names, grid properties, and named ranges. Use this to discover sheet names before reading.

## Batch update (formatting, merging, adding sheets)

```bash
gws sheets spreadsheets batchUpdate --params '{"spreadsheetId": "<SPREADSHEET_ID>"}' --json '{"requests": [{"addSheet": {"properties": {"title": "Summary"}}}]}'
```

Common request types: `addSheet`, `deleteSheet`, `mergeCells`, `repeatCell` (formatting), `autoResize`.

Confirm before overwriting existing data. Prefer append over update for adding new rows.
