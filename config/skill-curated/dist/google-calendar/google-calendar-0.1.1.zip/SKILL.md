---
name: google-calendar
description: "Interact with Google Calendar through the Google Calendar API using a Sanqian-provided access token."
---

# Google Calendar

## Overview

This skill is the runtime wrapper for Google Calendar event operations.

Supported operations:

- list upcoming events
- add a new event
- update an existing event
- delete an event

The runtime command surface is implemented by `scripts/google_calendar.py`.

## Runtime rules

- do not persist broker credentials or copied session data inside the skill package
- assume Sanqian provides a short-lived `GOOGLE_ACCESS_TOKEN` at request time
- treat calendar identity selection as setup metadata, not embedded credential logic

## Required runtime inputs

- `GOOGLE_ACCESS_TOKEN`
  Provided by Sanqian through the auth broker path for this skill.

Optional runtime inputs:

- `GOOGLE_CALENDAR_ID`
  Use a single calendar id. Defaults to `primary` when your host setup chooses that value.
- `GOOGLE_CALENDAR_IDS`
  Comma-separated list for multi-calendar listing workflows.

## Commands

```bash
python3 scripts/google_calendar.py list [--from <ISO> --to <ISO> --max <N>]
python3 scripts/google_calendar.py add --title <title> --start <ISO> --end <ISO> [--desc <description> --location <loc> --attendees <email1,email2>]
python3 scripts/google_calendar.py update --event-id <id> [--title <title> ...]
python3 scripts/google_calendar.py delete --event-id <id>
```

All commands print JSON to stdout and exit non-zero on error.

## Notes

- This curated runtime intentionally excludes the upstream credential bootstrap helper because credential exchange belongs in Sanqian, not in the skill package.
- This skill performs outbound requests to Google Calendar and should be treated as auth-bearing networked runtime.
