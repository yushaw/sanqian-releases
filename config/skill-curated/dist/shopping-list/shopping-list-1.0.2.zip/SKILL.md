---
name: shopping-list
description: "Maintain a conversational household shopping list with categories, check-off workflow, and monthly purchase history. Use for grocery lists, \"add to list\", \"what do we need\", restock-style questions, or purchase history queries."
metadata:
  version: "1.0.2"
---

# Shopping List

Manage a durable household shopping list through natural language. Keep runtime state outside the skill package.

## State Location

Use this directory for all persistent data:

- If `SANQIAN_DATA_DIR` is set: `$SANQIAN_DATA_DIR/skill-data/shopping-list/`
- Otherwise: `~/.sanqian/skill-data/shopping-list/`

Files:

- `active.json` - live list
- `config.json` - current user identity and reserved settings
- `history-YYYY-MM.json` - monthly purchase archive

For output examples and user-facing command shapes, read `references/commands.md`.

## Before Every Command

Run these checks in order before any shopping-list operation:

1. Ensure the state directory exists.
2. Ensure `active.json` exists. Default content:
   ```json
   {
     "items": [],
     "categories": ["Produce", "Dairy", "Meat", "Pantry", "Frozen", "Beverages", "Household", "Personal"],
     "lastModified": "<current ISO timestamp>"
   }
   ```
3. If `active.json` is invalid JSON, rename it to `active.json.corrupt`, create a fresh default file, and tell the user a backup was preserved.
4. Ensure `config.json` exists with `{ "user": null, "snoozes": {} }`.
5. If `config.json.user` is null and the request needs a mutation, ask: `What's your name? I'll use it to track who added each item.`
6. Run the archive process before handling the new request.

## Data Model

Each item in `active.json.items` must follow:

- `id`: unique ID. Prefer `uuidgen`; otherwise use `<ISO timestamp>-<4 hex chars>`.
- `name`: original trimmed display text.
- `normalizedName`: lowercase trimmed name. Use this for matching and dedupe.
- `quantity`: number or `null`.
- `unit`: free text or `null`.
- `category`: preset, custom, or `Uncategorized`.
- `checkedOff`: boolean.
- `checkedOffDate`: ISO timestamp or `null`.
- `addedBy`: lowercase user from `config.json`.
- `addedDate`: ISO timestamp.
- `notes`: free text or `null`.

Top-level `categories` starts with the 8 presets. Append custom categories when users explicitly create them.

## Core Behavior

### Add Items

- Parse one or more items from natural language.
- Infer categories silently when obvious:
  - milk/cheese/yogurt -> `Dairy`
  - chicken/beef/fish -> `Meat`
  - bananas/lettuce/onions -> `Produce`
  - rice/pasta/flour -> `Pantry`
  - dish soap/paper towels -> `Household`
  - shampoo/toothpaste -> `Personal`
  - juice/beer/wine -> `Beverages`
  - frozen pizza/ice cream -> `Frozen`
- If unclear, use `Uncategorized`.
- If a matching unchecked item already exists, update its quantity instead of creating a duplicate.
- If a matching checked item exists, uncheck it and update quantity if the user provided one.
- If the user explicitly names a new category, add it to `categories`.

### Check Off

Match by `normalizedName` with case-insensitive partial match.

- One match: set `checkedOff` and `checkedOffDate`.
- Multiple matches: ask which one.
- No match: show current candidates.

Checked items remain visible until archived.

### Remove

Delete the active item permanently. Do not archive mistaken entries.

### Edit

Editable fields: `name`, `quantity`, `unit`, `category`, `notes`.

- Recompute `normalizedName` if name changes.
- Add a category if the user explicitly changes to a new one.

### Change User

If the user says they are someone else, update `config.json.user`. New additions should use that identity in `addedBy`.

## Archive Process

Run this automatically before each command:

1. Read `active.json`.
2. Find items with `checkedOff = true` and `checkedOffDate` older than 24 hours.
3. If none qualify, stop.
4. Open or create `history-YYYY-MM.json` for the current month with `{ "month": "YYYY-MM", "archivedItems": [] }`.
5. Append qualifying items with an added `archivedDate`.
6. Write the history file first.
7. Remove archived items from `active.json`.
8. Write `active.json`.

`shopping clear` uses the same flow but archives all checked items immediately.

## Display Rules

Category order:

1. `Produce`, `Dairy`, `Meat`, `Pantry`, `Frozen`, `Beverages`, `Household`, `Personal`
2. Custom categories alphabetically
3. `Uncategorized` last

Within a category:

- sort alphabetically by `normalizedName`
- keep checked items visually distinct
- hide empty categories

## History Queries

For requests like `what did we buy last month`, read the relevant `history-YYYY-MM.json` file(s) and group results by archive date, newest first.

Important: history is based on archive date, not the original shopping date.
