---
name: gws-docs
description: "Create, read, and edit Google Docs documents. Use when the user mentions Google Docs, document editing, meeting notes, or wants to write/modify documents."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: external
      check_command: "gws auth status"
      check_success_pattern: "token_valid.*true"
---

# Google Docs

## Quick helpers

```bash
gws docs +write --document <DOC_ID> --text "Appended content"   # append text to end
```

## Create document

```bash
gws docs documents create --json '{"title": "Meeting Notes"}'
```

## Get document

```bash
gws docs documents get --params '{"documentId": "<DOC_ID>"}'
```

Returns structured body with paragraphs and elements. Each element has a `startIndex` and `endIndex`. Use these indices for insertion and formatting.

## Insert text

```bash
gws docs documents batchUpdate --params '{"documentId": "<DOC_ID>"}' --json '{
  "requests": [
    {
      "insertText": {
        "location": {"index": 1},
        "text": "Hello, world!\n"
      }
    }
  ]
}'
```

`index: 1` = beginning of document. Get the document first to find the target index from element boundaries.

## Replace text

```bash
gws docs documents batchUpdate --params '{"documentId": "<DOC_ID>"}' --json '{
  "requests": [
    {
      "replaceAllText": {
        "containsText": {"text": "old text", "matchCase": true},
        "replaceText": "new text"
      }
    }
  ]
}'
```

Confirm before modifying existing documents.
