#!/usr/bin/env node
/**
 * Minimal Asana API CLI for Sanqian.
 *
 * Runtime auth comes from ASANA_ACCESS_TOKEN, injected by Sanqian after the
 * user connects an Asana account. Only non-secret local defaults (such as a
 * preferred workspace) are persisted under ~/.sanqian/skill-data/asana/.
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const API_BASE = 'https://app.asana.com/api/1.0';

function die(msg) {
  console.error(msg);
  process.exit(1);
}

function stateDir() {
  return process.env.ASANA_STATE_DIR || path.join(os.homedir(), '.sanqian', 'skill-data', 'asana');
}

function configPath() {
  return path.join(stateDir(), 'config.json');
}

function loadConfig() {
  const p = configPath();
  if (!fs.existsSync(p)) return {};
  try {
    return JSON.parse(fs.readFileSync(p, 'utf-8')) || {};
  } catch {
    return {};
  }
}

function readAccessToken() {
  const token = process.env.ASANA_ACCESS_TOKEN;
  if (typeof token !== 'string' || token.trim() === '') {
    die(
      'Missing ASANA_ACCESS_TOKEN. Connect the Asana account in Sanqian first, then run the command again.',
    );
  }
  return token.trim();
}

async function asanaGet(pathname, token, query) {
  const url = new URL(API_BASE + pathname);
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v !== undefined && v !== null && v !== '') {
        url.searchParams.set(k, String(v));
      }
    }
  }
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Non-JSON response (${res.status}): ${text.slice(0, 300)}`);
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

async function asanaJson(method, pathname, token, body) {
  const url = API_BASE + pathname;
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Non-JSON response (${res.status}): ${text.slice(0, 300)}`);
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

const asanaPost = (pathname, token, body) => asanaJson('POST', pathname, token, body);
const asanaPut = (pathname, token, body) => asanaJson('PUT', pathname, token, body);

function parseArgs(argv) {
  const [cmd, ...rest] = argv;
  const flags = {};
  const positionals = [];
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const v = rest[i + 1] && !rest[i + 1].startsWith('--') ? rest[++i] : true;
      flags[k] = v;
    } else {
      positionals.push(a);
    }
  }
  return { cmd, flags, positionals };
}

function csvList(v) {
  if (!v) return [];
  return String(v)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

async function resolveMeGid(accessToken) {
  const me = await asanaGet('/users/me', accessToken);
  const gid = me?.data?.gid;
  if (!gid) throw new Error('Could not resolve /users/me gid');
  return String(gid);
}

function printJson(x) {
  console.log(JSON.stringify(x, null, 2));
}

async function main() {
  const { cmd, flags, positionals } = parseArgs(process.argv.slice(2));
  if (!cmd) {
    die(
      'Command required: me | workspaces | list-workspaces | set-default-workspace | projects | tasks-in-project | tasks-assigned | search-tasks | task | update-task | complete-task | comment | create-task',
    );
  }

  const accessToken = readAccessToken();
  const cfg = loadConfig();

  const getWorkspaceOrDefault = () => {
    const configured = process.env.ASANA_DEFAULT_WORKSPACE_GID || cfg.default_workspace_gid;
    const workspace = flags.workspace || configured;
    return workspace ? String(workspace) : null;
  };

  if (cmd === 'me') {
    printJson(await asanaGet('/users/me', accessToken));
    return;
  }

  if (cmd === 'workspaces' || cmd === 'list-workspaces') {
    printJson(await asanaGet('/workspaces', accessToken));
    return;
  }

  if (cmd === 'set-default-workspace') {
    const workspace = flags.workspace || positionals[0];
    if (!workspace) die('Usage: set-default-workspace --workspace <workspace_gid>');

    const outPath = configPath();
    const next = { ...cfg, default_workspace_gid: String(workspace) };
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, JSON.stringify(next, null, 2));
    console.log(`Saved default workspace to: ${outPath}`);
    console.log(`default_workspace_gid = ${next.default_workspace_gid}`);
    return;
  }

  if (cmd === 'projects') {
    const workspace = getWorkspaceOrDefault();
    if (!workspace) die('Missing --workspace <workspace_gid> (or set default via set-default-workspace)');
    const optFields = flags.opt_fields || 'gid,name,resource_type,archived,public';
    const r = await asanaGet('/projects', accessToken, {
      workspace,
      opt_fields: optFields,
      limit: flags.limit || 100,
    });
    printJson(r);
    return;
  }

  if (cmd === 'tasks-in-project') {
    const project = flags.project;
    if (!project) die('Missing --project <project_gid>');
    const optFields =
      flags.opt_fields ||
      'gid,name,completed,completed_at,assignee.name,assignee.gid,due_on,permalink_url,modified_at';
    const r = await asanaGet('/tasks', accessToken, {
      project,
      opt_fields: optFields,
      limit: flags.limit || 100,
    });
    printJson(r);
    return;
  }

  if (cmd === 'tasks-assigned') {
    const workspace = getWorkspaceOrDefault();
    if (!workspace) die('Missing --workspace <workspace_gid> (or set default via set-default-workspace)');
    const assignee = flags.assignee || 'me';
    const assigneeGid = assignee === 'me' ? await resolveMeGid(accessToken) : String(assignee);
    const optFields =
      flags.opt_fields ||
      'gid,name,completed,assignee.name,due_on,projects.name,permalink_url,modified_at';
    const r = await asanaGet('/tasks', accessToken, {
      workspace,
      assignee: assigneeGid,
      completed_since: flags.completed_since || 'now',
      opt_fields: optFields,
      limit: flags.limit || 100,
    });
    printJson(r);
    return;
  }

  if (cmd === 'search-tasks') {
    const workspace = getWorkspaceOrDefault();
    if (!workspace) die('Missing --workspace <workspace_gid> (or set default via set-default-workspace)');
    const query = { ...flags };
    delete query._;
    if (query.assignee === 'me') query['assignee.any'] = await resolveMeGid(accessToken);
    if (query.project) query['projects.any'] = String(query.project);
    delete query.assignee;
    delete query.project;

    const optFields = query.opt_fields || 'gid,name,completed,assignee.name,due_on,permalink_url';
    delete query.opt_fields;

    const r = await asanaGet(`/workspaces/${workspace}/tasks/search`, accessToken, {
      ...query,
      opt_fields: optFields,
      limit: query.limit || 100,
    });
    printJson(r);
    return;
  }

  if (cmd === 'task') {
    const gid = flags.gid || positionals[0];
    if (!gid) die('Usage: task <task_gid>');
    const optFields =
      flags.opt_fields ||
      'gid,name,completed,assignee.name,assignee.gid,due_on,notes,permalink_url,projects.name,memberships.section.name,modified_at';
    const r = await asanaGet(`/tasks/${gid}`, accessToken, { opt_fields: optFields });
    printJson(r);
    return;
  }

  if (cmd === 'update-task') {
    const gid = flags.gid || positionals[0];
    if (!gid) die('Usage: update-task <task_gid> [--name ...] [--notes ...] [--due_on YYYY-MM-DD] [--completed true|false]');

    const data = {};
    if (flags.name) data.name = String(flags.name);
    if (flags.notes) data.notes = String(flags.notes);
    if (flags.due_on) data.due_on = String(flags.due_on);
    if (flags.completed !== undefined) data.completed = String(flags.completed) === 'true' || flags.completed === true;

    if (Object.keys(data).length === 0) die('No fields provided to update.');

    const r = await asanaPut(`/tasks/${gid}`, accessToken, { data });
    printJson(r);
    return;
  }

  if (cmd === 'complete-task') {
    const gid = flags.gid || positionals[0];
    if (!gid) die('Usage: complete-task <task_gid>');
    const r = await asanaPut(`/tasks/${gid}`, accessToken, { data: { completed: true } });
    printJson(r);
    return;
  }

  if (cmd === 'comment') {
    const gid = flags.gid || flags.task || positionals[0];
    const text = flags.text;
    if (!gid) die('Usage: comment <task_gid> --text "..."');
    if (!text) die('Missing --text');
    const r = await asanaPost(`/tasks/${gid}/stories`, accessToken, { data: { text: String(text) } });
    printJson(r);
    return;
  }

  if (cmd === 'create-task') {
    const workspace = getWorkspaceOrDefault();
    const name = flags.name;
    const notes = flags.notes || '';
    const projects = flags.projects;
    if (!name) die('Missing --name');

    const data = { name, notes };
    if (workspace) data.workspace = String(workspace);
    if (projects) data.projects = csvList(projects);
    if (flags.due_on) data.due_on = String(flags.due_on);

    const r = await asanaPost('/tasks', accessToken, { data });
    printJson(r);
    return;
  }

  die(`Unknown command: ${cmd}`);
}

main().catch((e) => die(String(e?.stack || e)));
