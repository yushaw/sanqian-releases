---
name: google-calendar
description: "Manage Google Calendar events through a Google OAuth app configured on this device. Use when the user needs to inspect calendars, list events, create events, update events, or delete events."
---

# Google Calendar

## Overview

This skill uses the Google Calendar REST API through a Google OAuth app
configured on this device. You configure that app once in Sanqian, then reuse
the same Google provider setup across Google skills on this device. Sanqian
keeps the browser connect flow and refresh state local, and the runtime surface
only consumes a short-lived `GOOGLE_ACCESS_TOKEN`.

The main command surface lives in `scripts/google_calendar_api.mjs`.

## Runtime auth

- `GOOGLE_ACCESS_TOKEN`
  Short-lived access token injected by Sanqian after the user connects a Google
  account. Do not ask the user to paste authorization codes, refresh tokens,
  client IDs, or client secrets into this skill.

## Provider setup

Before you connect a Google account in Sanqian:

1. Create or select your own Google Cloud project.
2. Configure the OAuth consent screen under Google Auth Platform.
3. Enable the Google Calendar API. If the same Google provider config will also
   be reused for Google Tasks, enable the Google Tasks API too.
4. Create an OAuth Client ID of type `Web application`.
5. Add `https://auth.sanqian.ai/skills/auth/callback` as an authorized redirect
   URI.
6. Paste that app's `client_id` and `client_secret` into Sanqian's reusable
   Google provider configuration.
7. If the OAuth app is still in testing mode, add the Google account you plan
   to connect as a test user.

## Optional runtime env

- `GOOGLE_CALENDAR_ID`
  Optional default calendar id. When omitted, mutating commands default to
  `primary`, and read commands can still pass `--calendar <calendar_id>`.

## Quick Start

After Sanqian shows the Google Calendar account as connected:

```bash
node scripts/google_calendar_api.mjs calendars
node scripts/google_calendar_api.mjs list --calendar primary --max 10
```

Create an event:

```bash
node scripts/google_calendar_api.mjs add --title "Planning" --start 2026-03-20T09:00:00+08:00 --end 2026-03-20T10:00:00+08:00
```

## Commands

Inspect calendars and events:

```bash
node scripts/google_calendar_api.mjs calendars
node scripts/google_calendar_api.mjs list [--calendar primary] [--from 2026-03-20T00:00:00Z] [--to 2026-03-27T00:00:00Z] [--query release] [--max 10]
node scripts/google_calendar_api.mjs get --event-id <event_id> [--calendar primary]
```

Mutate events:

```bash
node scripts/google_calendar_api.mjs add --title "Planning" --start 2026-03-20T09:00:00+08:00 --end 2026-03-20T10:00:00+08:00 [--calendar primary] [--desc "agenda"] [--location "meeting room"] [--attendees a@example.com,b@example.com]
node scripts/google_calendar_api.mjs update --event-id <event_id> [--calendar primary] [--title "Updated"] [--start 2026-03-20T09:30:00+08:00] [--end 2026-03-20T10:30:00+08:00]
node scripts/google_calendar_api.mjs delete --event-id <event_id> [--calendar primary]
```

## Notes

- Required OAuth scopes are governed by the curated manifest, not by ad hoc
  local setup.
- This package intentionally removes the upstream refresh-token helper flow.
  Configuring your own Google OAuth app in Sanqian and then connecting your
  account is the only supported runtime model.
- Dates may be passed as RFC 3339 timestamps or all-day `YYYY-MM-DD` values.
