---
name: github
description: "Create and review pull requests, triage issues, check CI status, and search code on GitHub. Use when the user mentions GitHub, PRs, code review, issues, or CI builds."
metadata:
  sanqian:
    requires:
      bins: [gh]
    auth:
      mode: external
      check_command: "gh auth status"
      check_success_pattern: "Logged in to"
---

# GitHub

## Pull requests

```bash
gh pr list --state open --limit 20
gh pr list --json number,title,state,url --limit 10
gh pr view <number>                                    # summary, checks, review status
gh pr diff <number>
gh pr checks <number>
gh pr create --title "Fix bug" --body "Description"
gh pr merge <number> --merge                           # also: --squash, --rebase
```

## Issues

```bash
gh issue list --state open --limit 20
gh issue list --json number,title,labels,assignees --limit 10
gh issue view <number>
gh issue create --title "Bug report" --body "Description"
gh issue close <number>
gh issue edit <number> --add-label bug
```

## Repositories

```bash
gh repo list [owner] --limit 10
gh repo view [owner/repo]
gh repo clone owner/repo
```

## CI / Workflows

```bash
gh run list --json databaseId,status,conclusion,name --limit 5
gh run view <run-id>
gh workflow list
```

## Search

```bash
gh search repos "query" --limit 10
gh search issues "query" --limit 10
gh search prs "query" --limit 10
gh search code "query" --limit 10
```

## Releases

```bash
gh release list --limit 5
gh release create <tag> --title "v1.0" --notes "Release notes"
```

Use `--json` for structured output. Confirm before destructive operations (delete, merge, close).
