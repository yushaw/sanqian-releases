---
name: water-coach
description: Track water intake, body metrics, and hydration analytics with a local Python CLI. Use when the user wants to log water, check progress toward a hydration goal, review weekly or monthly summaries, or manage hydration-related reminders.
metadata:
  version: "1.7.0"
---

# Water Coach

Use the bundled CLI instead of calculating hydration state manually.

## First-Time Setup

Read `references/setup.md` the first time this skill is used.

Run:

```bash
python3 scripts/water_coach.py water setup
```

- If setup is incomplete, ask for either body weight or an explicit water goal.
- Ask for reminder times only during first-time setup.
- Do not overwrite an existing goal without confirmation.

## State Location

Persistent state must live outside the skill package:

- If `SANQIAN_DATA_DIR` is set: `$SANQIAN_DATA_DIR/skill-data/water-coach/`
- Otherwise: `~/.sanqian/skill-data/water-coach/`

Files:

- `water_log.csv`
- `water_config.json`
- `body_metrics.csv`

Optional audit context lookup can use `SANQIAN_SESSION_DIR` if the host app exposes it. If not set, audit falls back to entry-level metadata only.

## Core Commands

Use the CLI directly:

```bash
python3 scripts/water_coach.py <namespace> <command> [options]
```

Namespaces:

- `water`
- `body`
- `analytics`

Examples:

```bash
python3 scripts/water_coach.py water status
python3 scripts/water_coach.py water log 500
python3 scripts/water_coach.py water log 500 --drank-at=2026-02-18T18:00:00Z
python3 scripts/water_coach.py water dynamic
python3 scripts/water_coach.py water threshold
python3 scripts/water_coach.py water set_body_weight 80
python3 scripts/water_coach.py water set_body_weight 80 --update-goal
python3 scripts/water_coach.py water audit msg_123
python3 scripts/water_coach.py body log --weight=80 --height=1.75 --body-fat=18
python3 scripts/water_coach.py body latest
python3 scripts/water_coach.py body history 30
python3 scripts/water_coach.py analytics week
python3 scripts/water_coach.py analytics month
```

## Rules

1. Always use the CLI for calculations and status.
2. Interpret natural-language quantities first, then pass ml values to the CLI.
3. Use `water threshold` instead of hardcoding expected progress.
4. Treat weight-based goal (`weight * 35`) as a suggestion, not a mandate.
5. If the user provides a past drinking time, pass it via `--drank-at`.

## Data Rules

CSV columns:

```text
entry_id,logged_at,drank_at,date,slot,ml_drank,goal_at_time,message_id
```

- `drank_at` determines which day the water counts toward.
- `logged_at` is when the user told you.
- cumulative daily totals are calculated at query time.
- `message_id` is stored for audit, but reading transcript context should remain opt-in.

Read `references/log_format.md` for exact field behavior.

## Reminders and Analytics

- `water dynamic` decides whether an extra nudge is warranted right now.
- `analytics week` and `analytics month` build summaries from real logs; do not reconstruct them manually.
- Scheduled reminders are a host-orchestration concern. This skill provides the decision logic and CLI commands, not its own scheduler.

For dynamic reminder logic, read `references/dynamic.md`.
