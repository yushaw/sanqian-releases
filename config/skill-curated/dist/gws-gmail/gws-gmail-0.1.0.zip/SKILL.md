---
name: gws-gmail
description: "Send, read, search, and triage Gmail messages. Use when the user wants to check email, send messages, reply to threads, or search their inbox."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: external
      check_command: "gws auth status"
      check_success_pattern: "token_valid.*true"
---

# Gmail

## Quick actions

```bash
gws gmail +triage                   # summarize unread inbox
gws gmail +send --to alice@example.com --subject "Hello" --body "Message body"
gws gmail +reply --message-id <MSG_ID> --body "Thanks!"
gws gmail +reply-all --message-id <MSG_ID> --body "Group response"
gws gmail +forward --message-id <MSG_ID> --to bob@example.com
```

## Search and list messages

```bash
gws gmail users.messages list --params '{"userId": "me", "maxResults": 10}'
gws gmail users.messages list --params '{"userId": "me", "q": "is:unread from:alice"}'
gws gmail users.messages list --params '{"userId": "me", "q": "subject:report after:2026/01/01"}'
```

## Read a message

Use the message ID from the list result:

```bash
gws gmail users.messages get --params '{"userId": "me", "id": "<MSG_ID>"}'
```

## Labels

```bash
gws gmail users.labels list --params '{"userId": "me"}'
```

## Threads

```bash
gws gmail users.threads list --params '{"userId": "me", "maxResults": 10}'
gws gmail users.threads get --params '{"userId": "me", "id": "<THREAD_ID>"}'
```

Confirm before sending emails. Do not delete messages without user consent.
