---
name: google-tasks
description: "Manage Google Tasks through a Sanqian-managed Google OAuth connection. Use when the user needs to inspect task lists, list tasks, create tasks, complete tasks, or clean up Google Tasks."
---

# Google Tasks

## Overview

This skill uses the Google Tasks REST API through a Sanqian-managed Google OAuth
connection. Sanqian owns the OAuth client configuration, browser connect flow,
and refresh state. The runtime surface only consumes a short-lived
`GOOGLE_ACCESS_TOKEN`.

The main command surface lives in `scripts/google_tasks_api.mjs`.

## Runtime auth

- `GOOGLE_ACCESS_TOKEN`
  Short-lived access token injected by Sanqian after the user connects a Google
  account. Do not ask the user to paste authorization codes, refresh tokens,
  client IDs, or client secrets into this skill.

## Provider setup

Before the user can connect a Google account in Sanqian:

1. Create or select a Google Cloud project.
2. Configure the OAuth consent screen under Google Auth Platform.
3. Enable the Google Tasks API. If the same Google provider config will also be
   reused for Google Calendar, enable the Google Calendar API too.
4. Create an OAuth Client ID of type `Web application`.
5. Add `https://auth.sanqian.ai/skills/auth/callback` as an authorized redirect
   URI.
6. Paste the resulting `client_id` and `client_secret` into Sanqian's Google
   provider configuration.
7. If the OAuth app is still in testing mode, add the Google account you plan
   to connect as a test user.

## Optional runtime env

- `GOOGLE_TASKS_LIST_ID`
  Optional default task-list id. When omitted, commands that mutate or inspect a
  specific list should pass `--list <task_list_id>` explicitly.

## Quick Start

After Sanqian shows the Google Tasks account as connected:

```bash
node scripts/google_tasks_api.mjs lists
node scripts/google_tasks_api.mjs list --list <task_list_id>
```

Create a task:

```bash
node scripts/google_tasks_api.mjs create --list <task_list_id> --title "Finish review"
```

Complete it later:

```bash
node scripts/google_tasks_api.mjs complete --list <task_list_id> --task <task_id>
```

## Commands

Inspect task lists and tasks:

```bash
node scripts/google_tasks_api.mjs lists
node scripts/google_tasks_api.mjs list --list <task_list_id> [--show-completed true] [--max 50]
node scripts/google_tasks_api.mjs get --list <task_list_id> --task <task_id>
```

Mutate task lists:

```bash
node scripts/google_tasks_api.mjs create-list --title "Work"
node scripts/google_tasks_api.mjs update-list --list <task_list_id> --title "Updated title"
node scripts/google_tasks_api.mjs delete-list --list <task_list_id>
```

Mutate tasks:

```bash
node scripts/google_tasks_api.mjs create --list <task_list_id> --title "Buy groceries" [--notes "milk, eggs"] [--due 2026-03-20]
node scripts/google_tasks_api.mjs update --list <task_list_id> --task <task_id> [--title "Updated"] [--notes "Updated notes"] [--due 2026-03-22]
node scripts/google_tasks_api.mjs complete --list <task_list_id> --task <task_id>
node scripts/google_tasks_api.mjs reopen --list <task_list_id> --task <task_id>
node scripts/google_tasks_api.mjs delete --list <task_list_id> --task <task_id>
node scripts/google_tasks_api.mjs clear --list <task_list_id>
```

## Notes

- Required OAuth scopes are governed by the curated manifest, not by ad hoc
  local setup.
- This package intentionally removes the upstream `gog` / refresh-token setup
  flow. Brokered Google OAuth is the only supported runtime model in Sanqian.
- Dates may be passed as `YYYY-MM-DD` or RFC 3339 timestamps. Dates without a
  time are normalized to midnight UTC for Google Tasks.
