# AviationStack Setup

## Overview

This curated runtime requires `AVIATIONSTACK_API_KEY` to be set at request time.

Required setup item:

- `AVIATIONSTACK_API_KEY`

## Provider Notes

- AviationStack free tier is suitable for occasional personal lookups.
- The free tier is HTTP-only. If you need HTTPS transport, use a paid plan or do not surface this skill as a default recommendation.
- Usage quotas and plan selection are provider concerns, not runtime package state.

## Runtime Dependencies

- `python3`
- Python package: `requests`

## Operational Reminder

- Do not store the API key inside the skill package.
- Do not hardcode the API key into scripts or references.
