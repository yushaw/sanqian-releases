---
name: github
description: "Create and review pull requests, triage issues, check CI status, and search code on GitHub. Use when the user mentions GitHub, PRs, code review, issues, or CI builds."
metadata:
  sanqian:
    requires:
      bins: [gh]
      env:
        - name: GH_TOKEN
          source: host
          help_text: Short-lived GitHub OAuth access token injected by Sanqian at runtime for gh CLI. Do not ask users to paste personal access tokens in skill runtime.
          help_url: https://cli.github.com/manual/gh_help_environment
        - name: GITHUB_TOKEN
          source: host
          help_text: Compatibility alias injected by Sanqian for tools that expect GITHUB_TOKEN.
          help_url: https://cli.github.com/manual/gh_help_environment
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: github
      profile_id: oauth2.github.default
      brokered: true
      runtime_env_names: [GH_TOKEN, GITHUB_TOKEN]
      required_scopes:
        - repo
        - read:org
        - gist
      notes:
        - Sanqian stores GitHub refresh state on this device and injects GH_TOKEN/GITHUB_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gh auth login inside the install dialog.
---

# GitHub

## Pull requests

```bash
gh pr list --state open --limit 20
gh pr list --json number,title,state,url --limit 10
gh pr view <number>                                    # summary, checks, review status
gh pr diff <number>
gh pr checks <number>
gh pr create --title "Fix bug" --body "Description"
gh pr merge <number> --merge                           # also: --squash, --rebase
```

## Issues

```bash
gh issue list --state open --limit 20
gh issue list --json number,title,labels,assignees --limit 10
gh issue view <number>
gh issue create --title "Bug report" --body "Description"
gh issue close <number>
gh issue edit <number> --add-label bug
```

## Repositories

```bash
gh repo list [owner] --limit 10
gh repo view [owner/repo]
gh repo clone owner/repo
```

## CI / Workflows

```bash
gh run list --json databaseId,status,conclusion,name --limit 5
gh run view <run-id>
gh workflow list
```

## Search

```bash
gh search repos "query" --limit 10
gh search issues "query" --limit 10
gh search prs "query" --limit 10
gh search code "query" --limit 10
```

## Releases

```bash
gh release list --limit 5
gh release create <tag> --title "v1.0" --notes "Release notes"
```

Use `--json` for structured output. Confirm before destructive operations (delete, merge, close).
