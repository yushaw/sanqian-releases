---
name: track-flight
description: "Track flight status and route details with AviationStack using a Sanqian-managed API key."
---

# Track Flight

## Overview

This skill looks up flight status by IATA flight number and prints either formatted output or raw JSON.

Typical use cases:

- check whether a flight is delayed
- inspect departure and arrival details
- review gate, terminal, and live-position metadata when available

The runtime command surface lives in `scripts/track_flight.py`.

## Runtime rules

- keep the AviationStack API key outside the skill package
- assume Sanqian provides `AVIATIONSTACK_API_KEY` at request time
- treat provider plan limits and transport security as setup concerns, not hidden runtime assumptions

## Required runtime inputs

- `AVIATIONSTACK_API_KEY`
  Provider-issued key for AviationStack.

## Commands

```bash
python3 scripts/track_flight.py AA100
python3 scripts/track_flight.py UA2402
python3 scripts/track_flight.py BA123 --json
```

## Notes

- The upstream free-tier provider endpoint uses HTTP only. If this is not acceptable for your deployment, use a paid HTTPS-capable plan or keep the skill out of normal recommendation surfaces.
- This skill performs outbound network requests and should be treated as an API-key-backed lookup workflow.
