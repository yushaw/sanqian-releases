---
name: shopping-list
description: "Manage a household shopping list with add, check-off, archive, and review workflows. Use when the user wants to maintain grocery or household purchase items across multiple turns."
---

# Shopping List

Manage the household shopping list. Add items with quantities, check them off,
organize by category. Data lives in `skills/shopping-list/data/`.

For full command reference and output formats, read `skills/shopping-list/references/commands.md`.

## Before Every Command

Run these checks before every shopping list operation, in order:

1. If `skills/shopping-list/data/` directory does not exist, create it.
2. If `data/active.json` does not exist, create it with:
   ```json
   {
     "items": [],
     "updated_at": null
   }
   ```
3. If `data/archive/` does not exist, create it.

## Core Operations

### Add items

- Normalize obvious duplicates.
- Preserve quantities and notes.
- Update `data/active.json`.

### Check off items

- Mark purchased items as completed.
- Keep unchecked items in place.
- Update `updated_at`.

### Archive completed items

- Move completed items into a dated archive file under `data/archive/`.
- Leave only active items in `data/active.json`.

### Review the list

- Show active items grouped clearly.
- Call out anything recently archived when relevant.

## Safety

- Do not silently delete items.
- Confirm destructive rewrites if the user intent is unclear.
- If the active file is malformed, stop and repair it before continuing.

## References

- `skills/shopping-list/references/commands.md`
