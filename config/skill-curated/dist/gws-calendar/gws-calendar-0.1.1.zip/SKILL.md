---
name: gws-calendar
description: "Check today's agenda, create meetings and events, manage Google Calendar. Use when the user mentions schedule, meetings, appointments, calendar, or availability."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/calendar.events
        - https://www.googleapis.com/auth/calendar.calendarlist.readonly
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Google Calendar

## Quick helpers

```bash
gws calendar +agenda                    # today's agenda, default timezone
gws calendar +agenda --today --timezone Asia/Shanghai
gws calendar +insert --summary "Team standup" --start "2026-01-15T10:00:00" --end "2026-01-15T10:30:00"
```

## List events

```bash
gws calendar events list --params '{"calendarId": "primary", "maxResults": 10, "singleEvents": true, "orderBy": "startTime", "timeMin": "2026-01-01T00:00:00Z"}'
```

Set `singleEvents: true` to expand recurring events into individual instances.

## Create event

```bash
gws calendar events insert --params '{"calendarId": "primary"}' --json '{
  "summary": "Meeting",
  "start": {"dateTime": "2026-01-15T10:00:00", "timeZone": "Asia/Shanghai"},
  "end": {"dateTime": "2026-01-15T11:00:00", "timeZone": "Asia/Shanghai"},
  "attendees": [{"email": "alice@example.com"}]
}'
```

For all-day events, use `date` instead of `dateTime`: `"start": {"date": "2026-01-15"}`.

For recurring events, add `"recurrence": ["RRULE:FREQ=WEEKLY;COUNT=10"]`.

## Update event

```bash
gws calendar events patch --params '{"calendarId": "primary", "eventId": "<EVENT_ID>"}' --json '{"summary": "Updated Meeting"}'
```

## Delete event

```bash
gws calendar events delete --params '{"calendarId": "primary", "eventId": "<EVENT_ID>"}'
```

## List calendars

```bash
gws calendar calendarList list
```

Use `calendarId` from the list result to query non-primary calendars.

Confirm before creating events with attendees or deleting events.
