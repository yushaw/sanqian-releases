# Dynamic Scheduling

This file is only needed when tuning how `water dynamic` behaves.

## Concept

The dynamic check becomes more aggressive when the user is behind schedule and backs off when progress is healthy.

## Formula

```text
expected_percent = ((hour - start + 1) / (cutoff - start)) * 100
effective_threshold = expected_percent - margin_percent + aggressiveness_adjustment
```

## Relevant Config

`water_config.json` contains the reminder logic:

```json
{
  "settings": {
    "goal_multiplier": 35,
    "cutoff_hour": 22,
    "reminder_slots": [
      {"name": "morning", "hour": 9},
      {"name": "lunch", "hour": 12}
    ]
  },
  "dynamic_scheduling": {
    "enabled": true,
    "formula": {
      "margin_percent": 25,
      "start_hour": 9,
      "cutoff_hour": 22
    },
    "extra_notifications": {
      "max_per_day": 4,
      "interval_minutes": 30,
      "healthy_threshold_percent": 80
    }
  }
}
```

## Inspect Current Threshold

```bash
python3 scripts/water_coach.py water threshold
```

Typical response:

```json
{
  "expected_percent": 69.2,
  "threshold": 44.2,
  "margin_percent": 25,
  "current_hour": 17
}
```

## Check Whether to Nudge

```bash
python3 scripts/water_coach.py water dynamic
```

Typical response:

```json
{
  "should_send": true,
  "reason": "under_threshold",
  "current_percent": 45.1,
  "effective_threshold": 26.5
}
```

Host applications can use this response to decide whether to send a reminder.
