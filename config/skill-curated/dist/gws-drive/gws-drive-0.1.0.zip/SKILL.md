---
name: gws-drive
description: "Upload, download, search, and share files in Google Drive. Use when the user mentions Google Drive, cloud storage, file sharing, or wants to manage files and folders."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: external
      check_command: "gws auth status"
      check_success_pattern: "token_valid.*true"
---

# Google Drive

## List and search files

```bash
gws drive files list --params '{"pageSize": 10}'
gws drive files list --params '{"pageSize": 10, "q": "name contains \"budget\""}'
gws drive files list --params '{"pageSize": 10, "q": "mimeType=\"application/vnd.google-apps.folder\""}'
gws drive files list --params '{"pageSize": 10, "q": "mimeType=\"application/vnd.google-apps.spreadsheet\""}'
```

Common mimeType filters: `application/vnd.google-apps.folder`, `application/vnd.google-apps.document`, `application/vnd.google-apps.spreadsheet`, `application/vnd.google-apps.presentation`.

## Upload

```bash
gws drive +upload ./report.pdf --name "Q1 Report"
gws drive files create --json '{"name": "report.pdf", "parents": ["<FOLDER_ID>"]}' --upload ./report.pdf
```

## Download

```bash
gws drive files get --params '{"fileId": "<FILE_ID>", "alt": "media"}' > output.pdf
```

## Get file metadata

```bash
gws drive files get --params '{"fileId": "<FILE_ID>", "fields": "id,name,mimeType,size,modifiedTime"}'
```

## Create folder

```bash
gws drive files create --json '{"name": "New Folder", "mimeType": "application/vnd.google-apps.folder"}'
```

## Move / rename

```bash
gws drive files update --params '{"fileId": "<FILE_ID>"}' --json '{"name": "New Name"}'
gws drive files update --params '{"fileId": "<FILE_ID>", "addParents": "<FOLDER_ID>", "removeParents": "<OLD_FOLDER_ID>"}'
```

## Share

```bash
gws drive permissions create --params '{"fileId": "<FILE_ID>"}' --json '{"role": "reader", "type": "user", "emailAddress": "alice@example.com"}'
```

Roles: `reader`, `commenter`, `writer`. Confirm before deleting files or sharing.
