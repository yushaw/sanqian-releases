---
name: gws-chat
description: "Send and read messages in Google Chat spaces. Use when the user mentions Google Chat, team messaging, or wants to communicate with colleagues."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/chat.messages
        - https://www.googleapis.com/auth/chat.spaces
        - https://www.googleapis.com/auth/chat.memberships
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Google Chat

## List spaces

List spaces first to get the space ID:

```bash
gws chat spaces list
```

## Send message

```bash
gws chat +send --space spaces/<SPACE_ID> --text "Deploy complete."
```

Or via the API method:

```bash
gws chat spaces.messages create --params '{"parent": "spaces/<SPACE_ID>"}' --json '{"text": "Hello team!"}'
```

## Reply in a thread

```bash
gws chat spaces.messages create --params '{"parent": "spaces/<SPACE_ID>"}' --json '{"text": "Noted.", "thread": {"name": "spaces/<SPACE_ID>/threads/<THREAD_ID>"}}'
```

Get `thread.name` from an existing message in the list result.

## List messages in a space

```bash
gws chat spaces.messages list --params '{"parent": "spaces/<SPACE_ID>", "pageSize": 10}'
```

## List members

```bash
gws chat spaces.members list --params '{"parent": "spaces/<SPACE_ID>"}'
```

Confirm before sending messages to shared spaces.
