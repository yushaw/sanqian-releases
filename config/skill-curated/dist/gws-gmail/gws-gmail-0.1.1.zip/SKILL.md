---
name: gws-gmail
description: "Send, read, search, and triage Gmail messages. Use when the user wants to check email, send messages, reply to threads, or search their inbox."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/gmail.modify
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Gmail

## Quick actions

```bash
gws gmail +triage                   # summarize unread inbox
gws gmail +send --to alice@example.com --subject "Hello" --body "Message body"
gws gmail +reply --message-id <MSG_ID> --body "Thanks!"
gws gmail +reply-all --message-id <MSG_ID> --body "Group response"
gws gmail +forward --message-id <MSG_ID> --to bob@example.com
```

## Search and list messages

```bash
gws gmail users.messages list --params '{"userId": "me", "maxResults": 10}'
gws gmail users.messages list --params '{"userId": "me", "q": "is:unread from:alice"}'
gws gmail users.messages list --params '{"userId": "me", "q": "subject:report after:2026/01/01"}'
```

## Read a message

Use the message ID from the list result:

```bash
gws gmail users.messages get --params '{"userId": "me", "id": "<MSG_ID>"}'
```

## Labels

```bash
gws gmail users.labels list --params '{"userId": "me"}'
```

## Threads

```bash
gws gmail users.threads list --params '{"userId": "me", "maxResults": 10}'
gws gmail users.threads get --params '{"userId": "me", "id": "<THREAD_ID>"}'
```

Confirm before sending emails. Do not delete messages without user consent.
