---
name: google-tasks
description: "Manage Google Tasks through a Google OAuth app configured on this device. Use when the user needs to inspect task lists, list tasks, create tasks, complete tasks, or clean up Google Tasks."
---

# Google Tasks

## Overview

This skill uses the Google Tasks REST API through a Google OAuth app.
The main command surface lives in `scripts/google_tasks_api.mjs`.

## Runtime auth

- `GOOGLE_ACCESS_TOKEN`
  Short-lived OAuth access token. Do not ask the user to paste authorization
  codes, refresh tokens, client IDs, or client secrets into this skill.

## Optional runtime env

- `GOOGLE_TASKS_LIST_ID`
  Optional default task-list id. When omitted, commands that mutate or inspect a
  specific list should pass `--list <task_list_id>` explicitly.

## Quick Start

```bash
node scripts/google_tasks_api.mjs lists
node scripts/google_tasks_api.mjs list --list <task_list_id>
```

Create a task:

```bash
node scripts/google_tasks_api.mjs create --list <task_list_id> --title "Finish review"
```

Complete it later:

```bash
node scripts/google_tasks_api.mjs complete --list <task_list_id> --task <task_id>
```

## Commands

Inspect task lists and tasks:

```bash
node scripts/google_tasks_api.mjs lists
node scripts/google_tasks_api.mjs list --list <task_list_id> [--show-completed true] [--max 50]
node scripts/google_tasks_api.mjs get --list <task_list_id> --task <task_id>
```

Mutate task lists:

```bash
node scripts/google_tasks_api.mjs create-list --title "Work"
node scripts/google_tasks_api.mjs update-list --list <task_list_id> --title "Updated title"
node scripts/google_tasks_api.mjs delete-list --list <task_list_id>
```

Mutate tasks:

```bash
node scripts/google_tasks_api.mjs create --list <task_list_id> --title "Buy groceries" [--notes "milk, eggs"] [--due 2026-03-20]
node scripts/google_tasks_api.mjs update --list <task_list_id> --task <task_id> [--title "Updated"] [--notes "Updated notes"] [--due 2026-03-22]
node scripts/google_tasks_api.mjs complete --list <task_list_id> --task <task_id>
node scripts/google_tasks_api.mjs reopen --list <task_list_id> --task <task_id>
node scripts/google_tasks_api.mjs delete --list <task_list_id> --task <task_id>
node scripts/google_tasks_api.mjs clear --list <task_list_id>
```

## Notes

- Dates may be passed as `YYYY-MM-DD` or RFC 3339 timestamps. Dates without a
  time are normalized to midnight UTC for Google Tasks.
