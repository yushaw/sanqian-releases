---
name: asana
description: "Manage Asana tasks, projects, and workspaces through an OAuth app. Use when the user needs to inspect projects, search tasks, update tasks, add comments, or create new tasks in Asana."
---

# Asana

## Overview

This skill uses the Asana REST API through an OAuth app.
The main command surface lives in `scripts/asana_api.mjs`.

## Runtime auth

- `ASANA_ACCESS_TOKEN`
  Short-lived OAuth access token. Do not ask the user to paste refresh tokens
  into this skill.

## Optional runtime env

- `ASANA_STATE_DIR` -- override local config directory
- `ASANA_DEFAULT_WORKSPACE_GID` -- bypass the saved default workspace

## Quick Start

```bash
node scripts/asana_api.mjs me
node scripts/asana_api.mjs workspaces
```

Save a default workspace once:

```bash
node scripts/asana_api.mjs set-default-workspace --workspace <workspace_gid>
```

Then list projects or your assigned tasks:

```bash
node scripts/asana_api.mjs projects
node scripts/asana_api.mjs tasks-assigned --assignee me
```

## Commands

Inspect account and workspace data:

```bash
node scripts/asana_api.mjs me
node scripts/asana_api.mjs workspaces
node scripts/asana_api.mjs projects --workspace <workspace_gid>
```

Inspect or search tasks:

```bash
node scripts/asana_api.mjs tasks-in-project --project <project_gid>
node scripts/asana_api.mjs tasks-assigned --workspace <workspace_gid> --assignee me
node scripts/asana_api.mjs search-tasks --workspace <workspace_gid> --text "release" --assignee me
node scripts/asana_api.mjs task <task_gid>
```

Mutate tasks:

```bash
node scripts/asana_api.mjs update-task <task_gid> --name "New title" --due_on 2026-04-01
node scripts/asana_api.mjs complete-task <task_gid>
node scripts/asana_api.mjs comment <task_gid> --text "Update: shipped"
node scripts/asana_api.mjs create-task --workspace <workspace_gid> --name "Follow up"
```

