---
name: google-calendar
description: "Manage Google Calendar events through a Google OAuth app configured on this device. Use when the user needs to inspect calendars, list events, create events, update events, or delete events."
---

# Google Calendar

## Overview

This skill uses the Google Calendar REST API through a Google OAuth app.
The main command surface lives in `scripts/google_calendar_api.mjs`.

## Runtime auth

- `GOOGLE_ACCESS_TOKEN`
  Short-lived OAuth access token. Do not ask the user to paste authorization
  codes, refresh tokens, client IDs, or client secrets into this skill.

## Optional runtime env

- `GOOGLE_CALENDAR_ID`
  Optional default calendar id. When omitted, mutating commands default to
  `primary`, and read commands can still pass `--calendar <calendar_id>`.

## Quick Start

```bash
node scripts/google_calendar_api.mjs calendars
node scripts/google_calendar_api.mjs list --calendar primary --max 10
```

Create an event:

```bash
node scripts/google_calendar_api.mjs add --title "Planning" --start 2026-03-20T09:00:00+08:00 --end 2026-03-20T10:00:00+08:00
```

## Commands

Inspect calendars and events:

```bash
node scripts/google_calendar_api.mjs calendars
node scripts/google_calendar_api.mjs list [--calendar primary] [--from 2026-03-20T00:00:00Z] [--to 2026-03-27T00:00:00Z] [--query release] [--max 10]
node scripts/google_calendar_api.mjs get --event-id <event_id> [--calendar primary]
```

Mutate events:

```bash
node scripts/google_calendar_api.mjs add --title "Planning" --start 2026-03-20T09:00:00+08:00 --end 2026-03-20T10:00:00+08:00 [--calendar primary] [--desc "agenda"] [--location "meeting room"] [--attendees a@example.com,b@example.com]
node scripts/google_calendar_api.mjs update --event-id <event_id> [--calendar primary] [--title "Updated"] [--start 2026-03-20T09:30:00+08:00] [--end 2026-03-20T10:30:00+08:00]
node scripts/google_calendar_api.mjs delete --event-id <event_id> [--calendar primary]
```

## Notes

- Dates may be passed as RFC 3339 timestamps or all-day `YYYY-MM-DD` values.
