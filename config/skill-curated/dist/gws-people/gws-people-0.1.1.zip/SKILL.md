---
name: gws-people
description: "Search contacts and look up people in Google Contacts and organization directory. Use when the user needs someone's email, phone number, or contact information."
metadata:
  sanqian:
    requires:
      bins: [gws]
    auth:
      mode: oauth2
      kind: generic_oauth2
      provider: google
      profile_id: oauth2.google.workspace
      brokered: true
      runtime_env_names: [GOOGLE_WORKSPACE_CLI_TOKEN]
      required_scopes:
        - openid
        - https://www.googleapis.com/auth/userinfo.email
        - https://www.googleapis.com/auth/contacts
        - https://www.googleapis.com/auth/directory.readonly
      notes:
        - Sanqian stores Google refresh state on this device and injects GOOGLE_WORKSPACE_CLI_TOKEN only at request time.
        - Use Sanqian connect flow for this skill. Do not ask users to run gws auth setup/login inside the install dialog.
---

# Google Contacts

## Search contacts

```bash
gws people people searchContacts --params '{"query": "alice", "readMask": "names,emailAddresses"}'
```

Searches the user's personal contacts by name or email.

## Search organization directory

```bash
gws people people searchDirectoryPeople --params '{"query": "alice", "readMask": "names,emailAddresses", "sources": ["DIRECTORY_SOURCE_TYPE_DOMAIN_PROFILE"]}'
```

Only available for Google Workspace accounts. Searches the corporate directory.

## List contacts

```bash
gws people people.connections list --params '{"resourceName": "people/me", "pageSize": 10, "personFields": "names,emailAddresses,phoneNumbers"}'
```

## Get person details

```bash
gws people people get --params '{"resourceName": "people/<PERSON_ID>", "personFields": "names,emailAddresses,phoneNumbers,organizations"}'
```

The `resourceName` (e.g. `people/c12345`) comes from search or list results.

## Create contact

```bash
gws people people createContact --json '{
  "names": [{"givenName": "Alice", "familyName": "Smith"}],
  "emailAddresses": [{"value": "alice@example.com"}]
}'
```

## Update contact

```bash
gws people people updateContact --params '{"resourceName": "people/<PERSON_ID>", "updatePersonFields": "emailAddresses"}' --json '{"emailAddresses": [{"value": "newemail@example.com"}]}'
```

## Delete contact

```bash
gws people people deleteContact --params '{"resourceName": "people/<PERSON_ID>"}'
```

Confirm before creating, modifying, or deleting contacts.
